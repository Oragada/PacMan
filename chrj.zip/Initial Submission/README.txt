Name: Christian Jensen, chrj@itu.dk
Controller: EvolvedBehaviourPacman
This is a very basic decision tree, but its parameters (distance to Edible ghosts, dangerous ghosts and power pills) have been evolved with a genetic algorithm, given in the Evolution folder
The controller will need to be given running parameters, these are:
	EvolvedDecisionTree(78,76,5)
	